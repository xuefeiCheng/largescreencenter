caseInfo.drawLine = function() {
    //var container = document.querySelector('.line-content');
   	var myChart = echarts.init(document.getElementById('line-content'));
	var option = {
		tooltip: {
			trigger: 'axis',
			axisPointer: {
				type: 'shadow'
			}
		},
		grid: {
			top:'0%',
			left: '8%',
			right: '8%',
			bottom: '3%',
			containLabel: true 
		},
		xAxis: {
			show:false,
			type: 'value',
			boundaryGap: [0, 0.01]
		},
		yAxis: {
			type: 'category',
			data: [
				{value:'电子商务',textStyle:{color:"#fff",fontSize:16}},
				{value:'保险',textStyle:{color:"#fff",fontSize:16}},
				{value:'高新技术企业',textStyle:{color:"#fff",fontSize:16}},
				{value:'房地产',textStyle:{color:"#fff",fontSize:16}},
				{value:'担保',textStyle:{color:"#fff",fontSize:16}},
				{value:'投资理财',textStyle:{color:"#fff",fontSize:16}},
				{value:'小额贷款',textStyle:{color:"#fff",fontSize:16}},
				{value:'网贷平台',textStyle:{color:"#fff",fontSize:16}}, 
				{value:'投资咨询',textStyle:{color:"#fff",fontSize:16}},
				{value:'私募基金',textStyle:{color:"#fff",fontSize:16}},
			],
			splitLine:{
				show:false	
			},
			axisLine:{
				show:false	
			},
			axisTick:{
				show:false	
			}
		},
		series: [
			{
				name: '数量',
				type: 'bar',
				label:{
					normal:{
						show:true,
						position: 'right',
						textStyle:{
							color:"#fff"
						}
					}
				},
				barWidth:13,
				itemStyle: {
					normal: {
						color: new echarts.graphic.LinearGradient(0, 0, 1, 0, [{
							offset: 0,
							color: '#05a4f7' // 0% 处的颜色
						}, {
							offset: 1,
							color: '#62bef2' // 100% 处的颜色
						}], false)
					},
					emphasis:{
						color: new echarts.graphic.LinearGradient(0, 0, 1, 0, [{
							offset: 0,
							color: '#05a4f7' // 0% 处的颜色
						}, {
							offset: 1,
							color: '#62bef2' // 100% 处的颜色
						}], false)
					}
        		},
				data: [66, 85, 106,123, 210,237,260,1568,1937,2452]
			}
		]
	};
	myChart.setOption(option);
}
