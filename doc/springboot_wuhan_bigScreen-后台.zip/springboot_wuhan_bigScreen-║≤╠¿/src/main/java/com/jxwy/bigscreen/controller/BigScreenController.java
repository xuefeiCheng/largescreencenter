package com.jxwy.bigscreen.controller;

import com.jxwy.bigscreen.service.BigScreenSefvice;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.jws.WebResult;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;

@RestController
@RequestMapping("/index")
@CrossOrigin
public class BigScreenController {
    @Autowired
    private BigScreenSefvice bigScreenSefvice;
    /**
     * @desc:行业分类（直接分类+风险分类）
     * @param:flag为true时，表示行业风险（冒烟分数>40）分类；否则，直接行业分类
     * */
    @RequestMapping(value = "/hyfl",method= RequestMethod.POST)
    public Object industry(@RequestParam(value = "prov", required = false, defaultValue = "china") String prov,
                           @RequestParam(value = "city", required = false, defaultValue = "") String city,
                           @RequestParam(value = "cityArea", required = false, defaultValue = "") String cityArea,
                           @RequestParam(value = "flag" , required = false, defaultValue = "true") boolean flag,
                           @RequestParam(value = "title",required = false) String title,
                           HttpServletRequest request){
        Integer departmentId = 0;//定义此变量的目的是为了查询当前机构的关注企业，当前数据平台已去除关注企业的功能，所以当前随意赋予其0作为其值
        return bigScreenSefvice.industry(prov, city,cityArea,flag,departmentId,title);
    }
    /**
     * @desc:风险企业地区分布
     * @param:
     * @return:totalNumMap：该地区企业总数；
     *          allCaseList：所有企业地区分布；
     *          caseList：风险企业地区分布。
     * */
    @RequestMapping(value = "/map_new",method= RequestMethod.POST)
    public Object echartsMap_new(@RequestParam(value = "prov", required = false, defaultValue = "china") String prov,
                           @RequestParam(value = "city", required = false, defaultValue = "") String city,
                           @RequestParam(value = "cityArea", required = false, defaultValue = "") String cityArea){
        Integer departmentId = 0;//定义此变量的目的是为了查询当前机构的关注企业，当前数据平台已去除关注企业的功能，所以当前随意赋予其0作为其值
        return bigScreenSefvice.findCaseMapList(departmentId,prov,city,cityArea);
    }
    /**
     * @desc:监测企业按分数分类（饼图）
     * @param:
     * @return:{"高风险预警":"40","P2P企业异常名单":"0","企业异常名单":"0","调查介入":"3","重点监测":"108","全面排查":"12181","正常监测":"313","立案企业名单":"155"}
     * 其中“建议关注”对应“正常监测”，“建议核查”对应“重点监测”，“建议约谈”对应“高风险预警”，“建议移交线索”对应“调查介入”，“风险爆发”对应“P2P企业异常名单”，“立案侦查”对应“立案企业名单”
     * */
    @RequestMapping(value = "/echartPie_new",method= RequestMethod.POST)
    public Object echartPie_new(@RequestParam(value = "prov", required = false, defaultValue = "china") String prov,
                                 @RequestParam(value = "city", required = false, defaultValue = "") String city,
                                 @RequestParam(value = "cityArea", required = false, defaultValue = "") String cityArea){
        Integer departmentId = 0;//定义此变量的目的是为了查询当前机构的关注企业，当前数据平台已去除关注企业的功能，所以当前随意赋予其0作为其值
        return bigScreenSefvice.getInPieOption_new(departmentId,prov,city,cityArea);
    }

}
