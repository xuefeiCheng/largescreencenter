package com.jxwy.bigscreen.util.redis;

import com.jxwy.bigscreen.util.constant.PropertiesConfig;
import org.springframework.beans.factory.FactoryBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.Assert;
import redis.clients.jedis.JedisPool;
import redis.clients.jedis.JedisPoolConfig;

import javax.annotation.PostConstruct;

/**
 * redis连接池配置类
 * @author zeng
 *
 */
@Component
public class JedisPoolWrapper implements FactoryBean<JedisPool> {

	private JedisPoolConfig jedisPoolConfig;
	@Autowired
	private PropertiesConfig propertiesConfig;

	//private @Value("${redis.pool.maxIdle}") int maxIdle;
	//private @Value("${redis.pool.maxWait}") long maxWait;
	//private @Value("${redis.pool.maxTotal}") int maxTotal;
	//private @Value("${redis.pool.testOnBorrow}") boolean testOnBorrow;

	//private @Value("${redis.ip}") String host;
	//private @Value("${redis.port}") int port;

	/**
	 * 初始化
	 */
	public JedisPoolWrapper(){
		System.out.println("-----------");
	}
	@PostConstruct
	public void init() {
		jedisPoolConfig = new JedisPoolConfig();
		jedisPoolConfig.setMaxIdle(Integer.parseInt(propertiesConfig.getRedisMaxIdle()));
		jedisPoolConfig.setMaxTotal(Integer.parseInt(propertiesConfig.getRedisMaxWait()));
		jedisPoolConfig.setMaxWaitMillis(Integer.parseInt(propertiesConfig.getRedisMaxWait()));
		jedisPoolConfig.setTestOnBorrow(Boolean.parseBoolean(propertiesConfig.getRedisTestOnBorrow()));
        /*jedisPoolConfig.setMaxIdle(maxIdle);
        jedisPoolConfig.setMaxTotal(maxTotal);
        jedisPoolConfig.setMaxWaitMillis(maxWait);
        jedisPoolConfig.setTestOnBorrow(testOnBorrow);*/
	}

	@Override
	public JedisPool getObject() throws Exception {
		Assert.notNull(jedisPoolConfig, "initialize redis pool failed.");
		return new JedisPool(jedisPoolConfig,propertiesConfig.getRedisIp() , Integer.parseInt(propertiesConfig.getRedisPort()));
	}

	@Override
	public Class<?> getObjectType() {
		return JedisPool.class;
	}

	@Override
	public boolean isSingleton() {
		return true;
	}
}