package com.jxwy.bigscreen.dao.impl;

import com.jxwy.bigscreen.dao.BigScreenDao;

public class BigScreenDaoImpl implements BigScreenDao {
}
