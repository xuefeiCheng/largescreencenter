package com.jxwy.bigscreen.util;

import com.jxwy.bigscreen.util.constant.JxConstant;
import org.apache.http.HttpEntity;
import org.apache.http.HttpEntityEnclosingRequest;
import org.apache.http.HttpStatus;
import org.apache.http.NameValuePair;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.methods.HttpUriRequest;
import org.apache.http.client.utils.HttpClientUtils;
import org.apache.http.entity.StringEntity;
import org.apache.http.entity.mime.MultipartEntityBuilder;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.util.EntityUtils;
import org.apache.log4j.Logger;

import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;


/**
 * http请求调用接口工具类
 * @author zeng
 *
 */
public class HttpRequestUtils {
	
	private static Logger logger = Logger.getLogger(HttpRequestUtils.class);
	
	/**
	 * 处理get请求
	 * @param url 请求url地址，参数拼接到地址上
	 * @param headers 请求头，可以为null
	 * @return
	 */
	public static final String doGet(String url, Map<String, String> headers) throws Exception {
		HttpGet get = new HttpGet(url);
		setHeaders(get, headers);
		
		return executeAndGetResult(get, isHttps(url) ? getSslContext() : null);
	}
	
	/**
	 * 处理post请求
	 * @param url
	 * @param headers
	 * @param params
	 * @return
	 */
	public static final String doPostForm(String url, Map<String, String> headers,
			Map<String, String> params) throws Exception {
		HttpPost post = new HttpPost(url);
		// 设置请求头
		setHeaders(post, headers);
		// 设置请求参数
		setPostParams(post, params);
		
		// 执行请求
		return executeAndGetResult(post, isHttps(url) ? getSslContext() : null);
	}
	/**
	 * 执行post请求（设置内容体）
	 * @param url
	 * @param headers
	 * @param content
	 * @return
	 * @throws Exception
	 */
	public static final String doPostContent(String url, Map<String, String> headers, 
			String content) throws Exception {
		HttpPost httpPost = new HttpPost(url);
		// 设置请求头
		setHeaders(httpPost, headers);
		
		StringEntity stringEntity = new StringEntity(content, JxConstant.DEFAULT_CHARSET);
		httpPost.setEntity(stringEntity);
		// 执行请求
		return executeAndGetResult(httpPost, isHttps(url) ? getSslContext() : null);
	}
	/**
	 * 图片上传
	 * @param url
	 * @param name
	 * @param file
	 * @return
	 * @throws Exception
	 */
	public static final String doPostFile(String url, Map<String, String> headers, String name, File file) throws Exception {
		HttpPost httpPost = new HttpPost(url);
		
		setHeaders(httpPost, headers);
		HttpEntity httpEntity = MultipartEntityBuilder.create().addBinaryBody(name, file).build();
		httpPost.setEntity(httpEntity);
		
		return executeAndGetResult(httpPost, isHttps(url) ? getSslContext() : null);
	}
	
	/**
	 * 图片上传
	 * @param url
	 * @param name
	 * @param stream
	 * @return
	 * @throws Exception
	 */
	public static final String doPostStream(String url, Map<String, String> headers, String name, InputStream stream) throws Exception {
		HttpPost httpPost = new HttpPost(url);
		
		setHeaders(httpPost, headers);
		HttpEntity httpEntity = MultipartEntityBuilder.create().addBinaryBody(name, stream).build();
		httpPost.setEntity(httpEntity);
		
		return executeAndGetResult(httpPost, isHttps(url) ? getSslContext() : null);
	}
	/**
	 * 图片上传
	 * @param url
	 * @param name
	 * @param bytes
	 * @return
	 * @throws Exception
	 */
	public static final String doPostBytes(String url, Map<String, String> headers, 
			String name, byte[] bytes) throws Exception {
		HttpPost httpPost = new HttpPost(url);
		
		setHeaders(httpPost, headers);
		HttpEntity httpEntity = MultipartEntityBuilder.create().addBinaryBody(name, bytes).build();
		httpPost.setEntity(httpEntity);
		
		return executeAndGetResult(httpPost, isHttps(url) ? getSslContext() : null);
	}
	/**
	 * 设置请求头
	 * @param request
	 * @param headers
	 */
	private static void setHeaders(HttpUriRequest request, Map<String, String> headers) {
		if(headers != null && !headers.isEmpty()) {
			for(Map.Entry<String, String> entry : headers.entrySet()) {
				request.setHeader(entry.getKey(), entry.getValue());
			}
		}
	}
	/**
	 * 设置请求参数
	 * @param enclosingRequest
	 * @param params
	 * @throws IOException
	 */
	private static void setPostParams(HttpEntityEnclosingRequest enclosingRequest,
			Map<String, String> params) throws IOException {
		
		if(params != null && !params.isEmpty()) {
			List<NameValuePair> formParams = new ArrayList<NameValuePair>();
			for(Map.Entry<String, String> entry : params.entrySet()) {
				formParams.add(new BasicNameValuePair(entry.getKey(), entry.getValue()));
			}
			UrlEncodedFormEntity formEntity = new UrlEncodedFormEntity(formParams, JxConstant.DEFAULT_CHARSET);
			enclosingRequest.setEntity(formEntity);
		}
	}
	/**
	 * 判断是否为https请求
	 * @param url
	 * @return
	 */
	private static boolean isHttps(String url) throws IOException {
		String str = url.trim().toLowerCase();
		if(str.startsWith("https://"))
			return true;
		else if(str.startsWith("http://"))
			return false;
		else
			throw new IOException(url + "不是有效的url地址");
	}
	/**
	 * 执行请求
	 * @param httpUriRequest
	 * @return
	 * @throws IOException
	 */
	private static String executeAndGetResult(HttpUriRequest httpUriRequest, 
			SSLContext sslContext) throws IOException {
		HttpClientBuilder custom = HttpClients.custom();
		if(sslContext != null)
			custom.setSslcontext(sslContext);
		CloseableHttpClient client = custom.build();
		CloseableHttpResponse response = null;
		HttpEntity entity = null;
		try {
			response = client.execute(httpUriRequest);
			int statusCode = response.getStatusLine().getStatusCode();
			String result = "";
			if(statusCode == HttpStatus.SC_OK) {
				entity = response.getEntity();
				result = EntityUtils.toString(entity, JxConstant.DEFAULT_CHARSET);
			}
			return result;
		} finally {
			// 释放资源
			EntityUtils.consumeQuietly(entity);
			HttpClientUtils.closeQuietly(response);
			HttpClientUtils.closeQuietly(client);
		}
	}
	
	// 启用ssl协议，绕过安全证书认证
	private static SSLContext getSslContext() throws Exception {
		// 相信自己的CA和所有自签名的证书  
		SSLContext sslcontext = SSLContext.getInstance("TLS");
		sslcontext.init(null, new TrustManager[] {new X509TrustManager() {
			public X509Certificate[] getAcceptedIssuers() {
				return null;
			}
			public void checkServerTrusted(X509Certificate[] ax509certificate, String s)
					throws CertificateException {
			}
			public void checkClientTrusted(X509Certificate[] ax509certificate, String s)
					throws CertificateException {
			}
		}}, null);
		return sslcontext;
	}
}
