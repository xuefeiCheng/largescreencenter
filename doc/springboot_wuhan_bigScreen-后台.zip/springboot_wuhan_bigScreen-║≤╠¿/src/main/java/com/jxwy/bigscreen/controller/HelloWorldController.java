package com.jxwy.bigscreen.controller;

import com.jxwy.bigscreen.util.DataPlate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import java.util.HashMap;
import java.util.Map;

@RestController
public class HelloWorldController {
    @Autowired
    private DataPlate dataPlate;

    @RequestMapping("/hello")
    public String index() {
        String result = "";
        Map<String, Object> reqparam = new HashMap<String, Object>();
        reqparam.put("name", "上海洲实资产管理有限公司");
        try {
            result = dataPlate.getDataFromDataPlate("ys/basicInfo",reqparam);
            System.out.println(result);
        } catch (Exception e) {
            e.printStackTrace();
        }


        return "hello world";
    }
}
