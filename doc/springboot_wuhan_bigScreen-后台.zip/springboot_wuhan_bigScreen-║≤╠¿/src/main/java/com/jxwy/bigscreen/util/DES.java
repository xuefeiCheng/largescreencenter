package com.jxwy.bigscreen.util;

import com.jxwy.bigscreen.util.constant.JxConstant;
import org.apache.axis.encoding.Base64;

import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import java.security.SecureRandom;


public class DES {

	public DES(String desKey) {
		this.desKey = desKey.getBytes();
	}

	public byte[] desEncrypt(byte plainText[]) throws Exception {
		SecureRandom sr = new SecureRandom();
		byte rawKeyData[] = desKey;
		DESKeySpec dks = new DESKeySpec(rawKeyData);
		SecretKeyFactory keyFactory = SecretKeyFactory.getInstance("DES");
		javax.crypto.SecretKey key = keyFactory.generateSecret(dks);
		Cipher cipher = Cipher.getInstance("DES/ECB/PKCS5Padding");
		cipher.init(1, key, sr);
		byte data[] = plainText;
		byte encryptedData[] = cipher.doFinal(data);
		return encryptedData;
	}

	public byte[] desDecrypt(byte encryptText[]) throws Exception {
		SecureRandom sr = new SecureRandom();
		byte rawKeyData[] = desKey;
		DESKeySpec dks = new DESKeySpec(rawKeyData);
		SecretKeyFactory keyFactory = SecretKeyFactory.getInstance("DES");
		javax.crypto.SecretKey key = keyFactory.generateSecret(dks);
		Cipher cipher = Cipher.getInstance("DES/ECB/PKCS5Padding");
		cipher.init(2, key, sr);
		byte encryptedData[] = encryptText;
		byte decryptedData[] = cipher.doFinal(encryptedData);
		return decryptedData;
	}

	public String encrypt(String input) throws Exception {
		return new String(Base64.encode(desEncrypt(input.getBytes(JxConstant.DEFAULT_CHARSET))));
	}

	public String decrypt(String input) throws Exception {
		byte result[] = Base64.decode(input);
		return new String(desDecrypt(result), JxConstant.DEFAULT_CHARSET);
	}

	public String encrypt2(String input) throws Exception {
		return new String(desEncrypt(input.getBytes(JxConstant.DEFAULT_CHARSET)), JxConstant.DEFAULT_CHARSET);
	}

	public String decrypt2(String input) throws Exception {
		return new String(desDecrypt(input.getBytes(JxConstant.DEFAULT_CHARSET)), JxConstant.DEFAULT_CHARSET);
	}

	private byte desKey[];
}
