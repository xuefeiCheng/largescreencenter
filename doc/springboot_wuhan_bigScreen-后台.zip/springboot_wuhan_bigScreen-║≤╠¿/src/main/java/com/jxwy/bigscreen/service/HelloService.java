package com.jxwy.bigscreen.service;

public class HelloService {
}
