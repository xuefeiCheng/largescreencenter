package com.jxwy.bigscreen.util;

import com.jxwy.bigscreen.util.constant.JxConstant;
import com.jxwy.bigscreen.util.constant.PropertiesConfig;

import net.sf.json.JSONObject;
import org.apache.axis.encoding.Base64;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.HashMap;
import java.util.Map;

@Component
public class DataPlate {
	
	private static final Logger LOG = Logger.getLogger(DataPlate.class);
	@Autowired
	private PropertiesConfig propertiesConfig;
	/**
	 * @param:ath args
	 * @desc: 根据请求路径，请求参数对象获取数据平台数据
	 * */
	public String getDataFromDataPlate(String path,Object args) {
		Map<String,Object> queryParams = new HashMap<String,Object>();
		queryParams.put("reqParam", args);
		//正式服务器的参数
		queryParams.put("requestCode",propertiesConfig.getRequest_code());
		queryParams.put("username", propertiesConfig.getRequest_username());
		queryParams.put("password", propertiesConfig.getRequest_password());
		//本地的参数
		String encrypt = "";
		String encode = "";
		String str = "";
		try {
			encrypt = new DES(JxConstant.DES_KEY).encrypt(
			JSONObject.fromObject(queryParams).toString());
			encode = Base64.encode(encrypt.getBytes("UTF-8"));
			str = URLEncoder.encode(encode, "UTF-8");
		} catch (UnsupportedEncodingException e1) {
			LOG.error("", e1);
		} catch (Exception e1) {
			LOG.error("", e1);
		}
		
		Map<String, String> headers = new HashMap<String, String>();
		headers.put("Content-Type","application/json;charset=UTF-8" );
		
		String res="";
		try {
			res=HttpRequestUtils.doPostContent(propertiesConfig.getRequest_url()+path, headers, str);//需换成服务器的地址URL
		} catch (Exception e) {
			LOG.error(" 请求出错 ", e);
		}
		return res;
		
	}

	/**
	 * @param:ath args，pageNo,pageSize
	 * @desc: 根据请求路径，请求业务参数，页码，页数获取信息
	 * */
	public String getDataFromDataPlate(String path,Map args,int pageNo,int pageSize) {
		Map<String,Object> queryParams = new HashMap<String,Object>();
		queryParams.put("reqParam", args);
		queryParams.put("pageNo", pageNo);
		queryParams.put("pageSize", pageSize);
		//正式服务器的参数
		queryParams.put("requestCode",propertiesConfig.getRequest_code());
		queryParams.put("username", propertiesConfig.getRequest_username());
		queryParams.put("password", propertiesConfig.getRequest_password());
		//本地的参数
		String encrypt = "";
		String encode = "";
		String str = "";
		try {
			encrypt = new DES(JxConstant.DES_KEY).encrypt(
			JSONObject.fromObject(queryParams).toString());
			encode = Base64.encode(encrypt.getBytes("UTF-8"));
			str = URLEncoder.encode(encode, "UTF-8");
		} catch (UnsupportedEncodingException e1) {
			LOG.error("", e1);
		} catch (Exception e1) {
			LOG.error("", e1);
		}
		
		Map<String, String> headers = new HashMap<String, String>();
		headers.put("Content-Type","application/json;charset=UTF-8" );
		
		String res="";
		try {
			res=HttpRequestUtils.doPostContent(propertiesConfig.getRequest_url(), headers, str);//需换成服务器的地址URL
		} catch (Exception e) {
			LOG.error(" 请求出错 ", e);
		}
		return res;
		
	}

}
