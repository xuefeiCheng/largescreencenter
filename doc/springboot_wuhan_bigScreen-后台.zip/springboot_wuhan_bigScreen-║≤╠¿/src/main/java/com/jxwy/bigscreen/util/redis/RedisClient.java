package com.jxwy.bigscreen.util.redis;

import com.google.gson.Gson;
import com.jxwy.bigscreen.exception.TRSJXException;
import org.apache.commons.io.IOUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.Assert;
import redis.clients.jedis.Jedis;
import redis.clients.jedis.JedisPool;

import java.io.*;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Set;

/**
 * redis客户端操作类
 * @author zeng
 *
 */
@Component("redisClient")
public class RedisClient {

	private @Autowired
    JedisPool jedisPool;

	private static Logger logger = Logger.getLogger(RedisClient.class);

	/**
	 * 最大过期时间，以秒为单位（7天）
	 */
	public static final int MAX_EXPIRE_SECONDS =  7*24*60*60;
	/**
	 * 默认过期时间，以秒为单位（1天）
	 */
	public static final int DEFAULT_EXPIRE_SECONDS = 24*60*60;

	/**
	 * 获取所有key
	 * */
	public Set<?> getStringAll(String pattern){
		Jedis jedis = null;
		Set<?> keys = null;
		try {
			jedis = getJedis();
			keys = jedis.keys("*"+pattern+"*");
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return keys;
		
	}
	/**
	 * 存入数据，并设置过期时间
	 * @param key
	 * @param seconds
	 * @param value
	 * @return 状态码
	 */
	public String set(String key, int seconds, String value) {
		Jedis jedis = null;
		try {
			jedis = getJedis();
			return jedis.setex(key, seconds, value);
		} finally {
			consumeJedis(jedis);
		}
	}
	/**
	 * 保存数据，默认过期时间（1天）
	 * @param key
	 * @param value
	 */
	public String set(String key, String value) {
		return set(key, DEFAULT_EXPIRE_SECONDS, value);
	}
	/**
	 *
	 * @param key
	 * @param seconds
	 * @param value
	 * @param isToJson
	 * @return
	 */
	public <K, V> String set(K key, int seconds, V value, boolean isToJson) {
		if(isToJson)
			return set(isPrimaryType(key.getClass()) ? key.toString() : serializeStr(key),
					seconds, isPrimaryType(value.getClass()) ? value.toString() : serializeStr(value));
		else
			return set(serializeObj(key), seconds, serializeObj(value));
	}
	/**
	 * 保存数据
	 * @param key
	 * @param value
	 * @param isToJson  是否将key,value转json保存
	 * @return
	 */
	public <K, V> String set(K key, V value, boolean isToJson) {
		return set(key, DEFAULT_EXPIRE_SECONDS, value, isToJson);
	}
	/**
	 * 保存数据
	 * @param key
	 * @param seconds 过期时间
	 * @param value
	 * @return
	 */
	public <K, V> String set(K key, V value, int seconds) {
		return set(key, seconds, value, false);
	}
	/**
	 * 保存数据
	 * @param key
	 * @param value
	 * @return
	 */
	public <K, V> String set(K key, V value) {
		return set(key, value, DEFAULT_EXPIRE_SECONDS);
	}
	/**
	 * 保存数据，键和值都是字节数组
	 * @param key
	 * @param seconds
	 * @param value
	 * @return
	 */
	public String set(byte[] key, int seconds, byte[] value) {
		Jedis jedis = null;
		try {
			jedis = getJedis();
			return jedis.setex(key, seconds, value);
		} finally {
			consumeJedis(jedis);
		}
	}
	/**
	 * 判断是否存在
	 * @param key
	 * @return
	 */
	public boolean exits(String key) {
		Jedis jedis = null;
		try {
			jedis = getJedis();
			boolean result = jedis.exists(key);
			return result;
		} finally {
			consumeJedis(jedis);
		}
	}
	/**
	 * 判断是否存在
	 * @param key
	 * @return
	 */
	public boolean exits(byte[] key) {
		Jedis jedis = null;
		try {
			jedis = getJedis();
			boolean result = jedis.exists(key);
			return result;
		} finally {
			consumeJedis(jedis);
		}
	}
	/**
	 * 判断是否存在
	 * @param key
	 * @param isToJson key是否需要转为json
	 * @return
	 */
	public <K> boolean exits(K key, boolean isToJson) {
		if(isToJson)
			return exits(serializeStr(key));
		else
			return exits(serializeObj(key));
	}
	/**
	 * 获取数据(字符串)
	 * @param key
	 * @return
	 */
	public String getString(String key) {
		Jedis jedis = null;
		try {
			jedis = getJedis();
			String str = jedis.get(key);
			return str;
		} finally {
			consumeJedis(jedis);
		}
	}
	/**
	 * 获取数据（字节数组）
	 * @param key
	 * @return
	 */
	public byte[] getBytes(byte[] key) {
		Jedis jedis = null;
		try {
			jedis = getJedis();
			byte[] value = jedis.get(key);
			return value;
		} finally {
			consumeJedis(jedis);
		}
	}
	/**
	 * 获取数据（对象）
	 * @param key
	 * @param isToJson
	 * @param clz
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public <K, V> V getObj(K key, boolean isToJson, Class<V> clz) {
		if(isToJson) {
			String str = getString(serializeStr(key));
			return isPrimaryType(clz) ? (V) str : unserializeStr(str, clz);
		} else
			return unserializeObj(getBytes(serializeObj(key)), clz);
	}
	/**
	 * 获取数据
	 * @param key
	 * @param clz
	 * @return
	 */
	public <K, V> V getObj(K key, Class<V> clz) {
		return getObj(key, false, clz);
	}
	/**
	 * 删除数据
	 * @param keys
	 * @return
	 */
	public Long delete(String...keys) {
		Jedis jedis = null;
		try {
			jedis = getJedis();
			Long result = jedis.del(keys);
			return result;
		} finally {
			consumeJedis(jedis);
		}
	}
	/**
	 * 删除数据
	 * @param keys
	 * @return
	 */
	public Long delete(byte[]...keys) {
		Jedis jedis = null;
		try {
			jedis = getJedis();
			Long result = jedis.del(keys);
			return result;
		} finally {
			consumeJedis(jedis);
		}
	}
	/**
	 * 失效时间
	 * @param keys
	 * @return
	 */
	public Long expire(String key, int seconds) {
		Jedis jedis = null;
		try {
			jedis = getJedis();
			Long result = jedis.expire(key, seconds);
			return result;
		} finally {
			consumeJedis(jedis);
		}
	}
	/**
	 * 自增长
	 * @param key
	 * @return
	 */
	public Long increament(String key) {
		Jedis jedis = null;
		try {
			jedis = getJedis();
			Long result = jedis.incr(key);
			return result;
		} finally {
			consumeJedis(jedis);
		}
	}
	/**
	 * 删除数据
	 * @param isToJson
	 * @param keys
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public <K> Long delete(boolean isToJson, K...keys) {
		if(isToJson) {
			List<String> list = new ArrayList<String>();
			for(K k : keys) {
				list.add(serializeStr(k));
			}
			return delete(list.toArray(new String[list.size()]));
		} else {
			List<byte[]> list = new ArrayList<byte[]>();
			for(K k : keys) {
				list.add(serializeObj(k));
			}
			return delete(list.toArray(new byte[list.size()][]));
		}
	}
	/**
	 * 删除数据
	 * @param keys
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public <K> Long delete(K...keys) {
		return delete(false, keys);
	}

	/**
	 * 获得jedis
	 * @return
	 */
	private Jedis getJedis() {
		Assert.notNull(jedisPool, "initial injection jedisPool error.");
		return jedisPool.getResource();
	}

	/**
	 * 释放资源
	 * @param jedis
	 */
	private void consumeJedis(Jedis jedis) {
		if(jedis != null)
			jedis.close();
	}
	/**
	 * 将对象序列化为json串
	 * @param obj
	 * @return
	 */
	private static String serializeStr(Object obj) {
		return new Gson().toJson(obj);
	}
	/**
	 * 将json串反序列化为对象
	 * @param jsonStr
	 * @param clz
	 * @return
	 */
	private static <T> T unserializeStr(String jsonStr, Class<T> clz) {
		return new Gson().fromJson(jsonStr, clz);
	}
	/**
	 * 判断是否为基本类型
	 * @param obj
	 * @return
	 */
	private static boolean isPrimaryType (Class<?> clz) {
		return Number.class.isAssignableFrom(clz) || clz == Character.class || clz.isPrimitive()
				|| clz == Boolean.class || clz == String.class || Date.class.isAssignableFrom(clz);
	}
	/**
	 * 将对象序列化为字节数组
	 * @param obj
	 * @return
	 */
	private static byte[] serializeObj(Object obj) {
		if(!Serializable.class.isAssignableFrom(obj.getClass()))
			throw new TRSJXException("the object can not serialize.");

		ObjectOutputStream oos = null;
		try {
			ByteArrayOutputStream baos = new ByteArrayOutputStream();
			oos = new ObjectOutputStream(baos);
			oos.writeObject(obj);
			oos.flush();
			byte[] bs = baos.toByteArray();
			return bs;
		} catch(Exception e) {
			logger.error("serialize obj error.", e);
			throw new TRSJXException(e);
		} finally {
			IOUtils.closeQuietly(oos);
		}
	}
	/**
	 * 将字节数组反序列化为对象
	 * @param bs
	 * @param clz
	 * @return
	 */
	@SuppressWarnings("unchecked")
	private static <T> T unserializeObj(byte[] bs, Class<T> clz) {
		if(!Serializable.class.isAssignableFrom(clz))
			throw new TRSJXException("the byte array can not unserialize to clz");

		ObjectInputStream ois = null;
		try {
			ByteArrayInputStream bais = new ByteArrayInputStream(bs);
			ois = new ObjectInputStream(bais);
			T t = (T) ois.readObject();
			return t;
		} catch(Exception e) {
			logger.error("unserialize error.", e);
			throw new TRSJXException(e);
		} finally {
			IOUtils.closeQuietly(ois);
		}
	}
}