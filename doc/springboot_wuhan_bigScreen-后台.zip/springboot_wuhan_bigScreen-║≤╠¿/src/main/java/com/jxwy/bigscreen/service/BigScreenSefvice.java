package com.jxwy.bigscreen.service;

import net.sf.json.JSONObject;

import java.util.Map;

public interface BigScreenSefvice {
    Object industry(String province, String city, String cityArea,boolean flag,Integer departmentId,String title);
    public JSONObject findCaseMapList(Integer departmentId, String prov, String city,
                                              String cityArea);
    JSONObject getInPieOption_new(Integer departmentid, String prov, String city, String cityArea);
}
