package com.jxwy.bigscreen.service.Impl;

import com.jxwy.bigscreen.service.BigScreenSefvice;
import com.jxwy.bigscreen.util.DataPlate;
import com.jxwy.bigscreen.util.constant.PropertiesConfig;
import com.jxwy.bigscreen.util.redis.RedisClient;
import net.sf.json.JSONObject;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.Map;

@Service("BigScreenService")
public class BigScreenServiceImpl implements BigScreenSefvice{
    @Autowired
    private RedisClient redisClient;
    @Autowired
    private DataPlate dataPlate;
    @Autowired
    private PropertiesConfig propertiesConfig;
    @SuppressWarnings({"rawtypes", "unchecked"})
    @Override
    public Object industry(String province, String city, String cityArea, boolean flag, Integer departmentId, String title) {
        Map param = new HashMap();
        Map returnMap = new HashMap();
        try {
            param.put("province", province);
            param.put("city", city);
            param.put("cityArea", cityArea);
            param.put("flag", flag);
            param.put("departmentid", departmentId);
            if(title!=null){
                param.put("title", title);
            }else{
                param.put("title", "");
            }
            String key = propertiesConfig.getPlatflag()+ "/index/hyfl"+ province + city + cityArea + flag;
            String string = redisClient.getString(key);
            JSONObject jsonObject = new JSONObject();
            if (string == null || string.isEmpty() ||string.equals("null")) {
                String result = dataPlate.getDataFromDataPlate("categroyCount", param);
                jsonObject = JSONObject.fromObject(result).getJSONObject("resultData");
                if (!result.isEmpty()) {
                    redisClient.set(key, redisClient.MAX_EXPIRE_SECONDS, jsonObject.toString());
                }
            } else {
                jsonObject = JSONObject.fromObject(string);
            }
            returnMap.put("classify", jsonObject.keySet());
            returnMap.put("count", jsonObject.values());

        }catch (Exception e){
            e.printStackTrace();
        }
        return returnMap;
    }

    @Override
    public JSONObject findCaseMapList(Integer departmentId, String prov, String city, String cityArea) {
        Map param = new HashMap();
        JSONObject jsonObject = new JSONObject();
        try {
            param.put("prov", prov);
            param.put("city", city);
            param.put("cityArea", cityArea);
            param.put("departmentId", departmentId);
            String key = propertiesConfig.getPlatflag()+ "/index/map_new" + prov + city + cityArea;
            String string = redisClient.getString(key);

            if (string == null || string.isEmpty() ||string.equals("null")) {
                String result = dataPlate.getDataFromDataPlate("case/mapCaseList_wuhan", param);
                jsonObject = JSONObject.fromObject(result).getJSONObject("resultData");
                if (!result.isEmpty()) {
                    redisClient.set(key, redisClient.MAX_EXPIRE_SECONDS, jsonObject.toString());
                }
            } else {
                jsonObject = JSONObject.fromObject(string);
            }
        }catch (Exception e){
            e.printStackTrace();
        }
        return jsonObject;
    }

    @Override
    public JSONObject getInPieOption_new(Integer departmentId, String prov, String city, String cityArea) {
        Map param = new HashMap();
        JSONObject jsonObject = new JSONObject();
        try {
            param.put("pro", prov);
            param.put("city", city);
            param.put("cityArea", cityArea);
            param.put("departmentid", departmentId);
            param.put("classify","");//暂时用不到，传空字符串
            String key = propertiesConfig.getPlatflag()+ "/index/echartPie_new" + prov + city + cityArea;
            String string = redisClient.getString(key);

            if (string == null || string.isEmpty() ||string.equals("null")) {
                String result = dataPlate.getDataFromDataPlate("getFinancaseScore", param);
                jsonObject = JSONObject.fromObject(result).getJSONObject("resultData");
                if (!result.isEmpty()) {
                    redisClient.set(key, redisClient.MAX_EXPIRE_SECONDS, jsonObject.toString());
                }
            } else {
                jsonObject = JSONObject.fromObject(string);
            }
        }catch (Exception e){
            e.printStackTrace();
        }
        return jsonObject;
    }

}
