package com.jxwy.bigscreen.service.Impl;

public class HelloServiceImpl {
}
