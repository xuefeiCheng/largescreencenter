package com.jxwy.bigscreen.util.constant;

import lombok.Data;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Component;

@Component
@Data
public class PropertiesConfig {

    @Value("${platflag}")
    private String platflag;//平台标志
    @Value("${request_url}")
    private  String request_url ;
    @Value("${request_code}")
    private  String request_code;
    @Value("${request_username}")
    private  String request_username;
    @Value("${request_password}")
    private  String request_password;
    @Value("${redis.pool.maxIdle}")
    private String redisMaxIdle;
    @Value("${redis.pool.maxWait}")
    private String redisMaxWait;
    @Value("${redis.pool.maxTotal}")
    private String redisMaxTotal;
    @Value("${redis.pool.testOnBorrow}")
    private String redisTestOnBorrow;
    @Value("${redis.ip}")
    private String redisIp;
    @Value("${redis.port}")
    private String redisPort;
    @Value("${redis.flag}")
    private String redisFlag;

}
