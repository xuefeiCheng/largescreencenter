package com.jxwy.bigscreen.util.constant;


/**
 * 常用常量
 * @author zengnq
 * 
 * 2015年9月28日
 */
public final class JxConstant {
	/**
	 * 请求校验码
	 */
	public static final String REQUEST_CODE = "1d6348ee9b6438afb74007bec9b5ae32";
	/**
	 * 请求串加密key
	 */
	public static final String DES_KEY = "jinxinwangyin01";
	
	/**
	 * 法院数据库名
	 */
	public static final String COURT_DATABASE_NAME = "AS$2$14$1";
	/**
	 * 舆情数据库名
	 */
	public static final String POP_SENTIMENT_DATABASE_NAME="AS$1$B$2";
	/**
	 * 请求参数存request的key
	 */
	public static final String REQUEST_ATTR_KEY = "attr";
	/**
	 * 每天最大访问次数
	 */
//	public static final int MAX_TIMES_PER_DAY = Integer.parseInt(PropertiesUtils.getValue("max_times"));
//	/**
//	 * 请求超时时间，30分钟
//	 */
//	public static final int OVER_TIME_MINUTE = Integer.parseInt(PropertiesUtils.getValue("max_over_time"));
	/**
	 * 访问次数map存储的key值
	 */
	public static final String ACCESS_MAP_KEY = "accessMap";
	/**
	 * 访问次数key前缀
	 */
	public static final String ACCESS_KEY_PREF = "JXWY_";
	/**
	 * 默认编码
	 */
	public static final String DEFAULT_CHARSET = "UTF-8";
	
}
