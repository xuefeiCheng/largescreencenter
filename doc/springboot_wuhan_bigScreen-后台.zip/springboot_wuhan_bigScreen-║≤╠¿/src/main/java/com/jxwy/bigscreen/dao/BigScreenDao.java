package com.jxwy.bigscreen.dao;

public interface BigScreenDao {
}
