package com.jxwy.bigscreen.exception;

/**
 * 
 * @author zengnq
 * 
 * 2015年9月28日
 */
public class TRSJXException extends RuntimeException {

	private static final long serialVersionUID = -418148236181823935L;
	
	public TRSJXException() {
		super();
	}
	
	public TRSJXException(String message) {
		super(message);
	}
	
	public TRSJXException(Throwable t) {
		super(t);
	}
	
	public TRSJXException(String message, Throwable t) {
		super(message, t);
	}
}
